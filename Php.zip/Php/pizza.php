<html>
<body>
<style>
        body {
          background-image: url('pizzabg-transformed.jpeg');
          background-repeat: no-repeat;
          background-attachment: fixed;
          background-size: cover;
      }
    </style>
    <center><img src="pizza_logo-removebg-preview.png" alt="pizza logo" width="200" height="200"></center>
    <center><p style="color:#FFFF00 "> <b><i>YOUR ORDER</b></i><p> </center>
<div align="center">
<?php
$username=$_POST['user'];
$mobnumber=$_POST['mobnum'];
foreach($_POST['Grill'] as $g)
{
echo "<font color=yellow><li><b><mark>GRILL:</mark>&nbsp;</b> $g </li>\r\n</font>";
}
foreach($_POST['Plain'] as $p)
{
echo "<font color=yellow><li><b><mark>PLAIN:</mark>&nbsp;</b> $p </li>\r\n</font>";
}
foreach($_POST['Burger'] as $b)
{
echo "<font color=yellow><li><b><mark>BURGER</mark>&nbsp;</b> $b </li>\r\n</font><br>";
}
echo"<font color=yellow><b>PIZZA TOPPINGS:&nbsp;</b>\r\n</font>";
foreach($_POST['Veg'] as $v)
{
echo "<font color=yellow><li><b><mark>VEG:</mark>&nbsp;&nbsp;</b> $v </li>\r\n</font>";
}
foreach($_POST['Non_Veg'] as $nv)
{
echo "<font color=yellow><li><b><mark>NON-VEG:</mark>&nbsp;</b> $nv </li>\r\n</font>";
}
    echo"<br><br><br><br><br><marquee><font color=yellow><b><mark>THANK YOU FOR YOUR ORDER:&nbsp;&nbsp;$username</mark>&nbsp;</b>\r\n</font></marquee><";
    echo"<br>";
echo"<marquee><font color=yellow><b><mark>YOUR DELIVERY PARTNER'S DETAILS WILL BE SENT TO YOUR PHONE:&nbsp;&nbsp;$mobnumber</mark>&nbsp;</b>\r\n</font></marquee>";
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.checked {
  color: orange;
}
</style>
<h2>Star Rating</h2>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked">
</div>
<center><img src="cash-back-removebg-preview.png" alt="pizza logo" width="150" height="150">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="fastfooddelivery-removebg-preview-transformed.png"alt="pizza logo" width="150" height="150"></center>
</body>
</html>